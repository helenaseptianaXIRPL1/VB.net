﻿Public Class Form2
    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub
End Class