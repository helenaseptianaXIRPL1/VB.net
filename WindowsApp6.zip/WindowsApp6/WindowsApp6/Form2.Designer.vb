﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lbl_nama = New System.Windows.Forms.Label()
        Me.lbl_pem2 = New System.Windows.Forms.Label()
        Me.lbl_pem1 = New System.Windows.Forms.Label()
        Me.lbl_pem3 = New System.Windows.Forms.Label()
        Me.lbl_harga1 = New System.Windows.Forms.Label()
        Me.lbl_harga2 = New System.Windows.Forms.Label()
        Me.lbl_harga3 = New System.Windows.Forms.Label()
        Me.lbl_jmh1 = New System.Windows.Forms.Label()
        Me.lbl_jmh2 = New System.Windows.Forms.Label()
        Me.lbl_jmh3 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.tb = New System.Windows.Forms.Label()
        Me.tt1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.tt2 = New System.Windows.Forms.Label()
        Me.tt3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(548, 240)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 13)
        Me.Label8.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(444, 149)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Jumlah   :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(548, 209)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 21
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(105, 261)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 13)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Pembelian 3   :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(105, 209)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Pembelian 2   :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(105, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Pembelian 1   :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(105, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Nama   :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(327, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "TOKO GORENGAN ABC"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(290, 149)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 35
        Me.Label9.Text = "Harga   :"
        '
        'lbl_nama
        '
        Me.lbl_nama.AutoSize = True
        Me.lbl_nama.Location = New System.Drawing.Point(158, 106)
        Me.lbl_nama.Name = "lbl_nama"
        Me.lbl_nama.Size = New System.Drawing.Size(76, 13)
        Me.lbl_nama.TabIndex = 36
        Me.lbl_nama.Text = "......................."
        '
        'lbl_pem2
        '
        Me.lbl_pem2.AutoSize = True
        Me.lbl_pem2.Location = New System.Drawing.Point(188, 209)
        Me.lbl_pem2.Name = "lbl_pem2"
        Me.lbl_pem2.Size = New System.Drawing.Size(76, 13)
        Me.lbl_pem2.TabIndex = 37
        Me.lbl_pem2.Text = "......................."
        '
        'lbl_pem1
        '
        Me.lbl_pem1.AutoSize = True
        Me.lbl_pem1.Location = New System.Drawing.Point(188, 149)
        Me.lbl_pem1.Name = "lbl_pem1"
        Me.lbl_pem1.Size = New System.Drawing.Size(76, 13)
        Me.lbl_pem1.TabIndex = 38
        Me.lbl_pem1.Text = "......................."
        '
        'lbl_pem3
        '
        Me.lbl_pem3.AutoSize = True
        Me.lbl_pem3.Location = New System.Drawing.Point(188, 261)
        Me.lbl_pem3.Name = "lbl_pem3"
        Me.lbl_pem3.Size = New System.Drawing.Size(76, 13)
        Me.lbl_pem3.TabIndex = 39
        Me.lbl_pem3.Text = "......................."
        '
        'lbl_harga1
        '
        Me.lbl_harga1.AutoSize = True
        Me.lbl_harga1.Location = New System.Drawing.Point(344, 149)
        Me.lbl_harga1.Name = "lbl_harga1"
        Me.lbl_harga1.Size = New System.Drawing.Size(76, 13)
        Me.lbl_harga1.TabIndex = 40
        Me.lbl_harga1.Text = "......................."
        '
        'lbl_harga2
        '
        Me.lbl_harga2.AutoSize = True
        Me.lbl_harga2.Location = New System.Drawing.Point(344, 209)
        Me.lbl_harga2.Name = "lbl_harga2"
        Me.lbl_harga2.Size = New System.Drawing.Size(76, 13)
        Me.lbl_harga2.TabIndex = 41
        Me.lbl_harga2.Text = "......................."
        '
        'lbl_harga3
        '
        Me.lbl_harga3.AutoSize = True
        Me.lbl_harga3.Location = New System.Drawing.Point(344, 261)
        Me.lbl_harga3.Name = "lbl_harga3"
        Me.lbl_harga3.Size = New System.Drawing.Size(76, 13)
        Me.lbl_harga3.TabIndex = 42
        Me.lbl_harga3.Text = "......................."
        '
        'lbl_jmh1
        '
        Me.lbl_jmh1.AutoSize = True
        Me.lbl_jmh1.Location = New System.Drawing.Point(502, 149)
        Me.lbl_jmh1.Name = "lbl_jmh1"
        Me.lbl_jmh1.Size = New System.Drawing.Size(76, 13)
        Me.lbl_jmh1.TabIndex = 43
        Me.lbl_jmh1.Text = "......................."
        '
        'lbl_jmh2
        '
        Me.lbl_jmh2.AutoSize = True
        Me.lbl_jmh2.Location = New System.Drawing.Point(502, 209)
        Me.lbl_jmh2.Name = "lbl_jmh2"
        Me.lbl_jmh2.Size = New System.Drawing.Size(76, 13)
        Me.lbl_jmh2.TabIndex = 44
        Me.lbl_jmh2.Text = "......................."
        '
        'lbl_jmh3
        '
        Me.lbl_jmh3.AutoSize = True
        Me.lbl_jmh3.Location = New System.Drawing.Point(502, 261)
        Me.lbl_jmh3.Name = "lbl_jmh3"
        Me.lbl_jmh3.Size = New System.Drawing.Size(76, 13)
        Me.lbl_jmh3.TabIndex = 45
        Me.lbl_jmh3.Text = "......................."
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(347, 49)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(94, 13)
        Me.Label20.TabIndex = 46
        Me.Label20.Text = "STRUK BELANJA"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(502, 341)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(135, 13)
        Me.Label21.TabIndex = 47
        Me.Label21.Text = "Total yang harus dibayar   :"
        '
        'tb
        '
        Me.tb.AutoSize = True
        Me.tb.Location = New System.Drawing.Point(638, 341)
        Me.tb.Name = "tb"
        Me.tb.Size = New System.Drawing.Size(76, 13)
        Me.tb.TabIndex = 48
        Me.tb.Text = "......................."
        '
        'tt1
        '
        Me.tt1.AutoSize = True
        Me.tt1.Location = New System.Drawing.Point(638, 149)
        Me.tt1.Name = "tt1"
        Me.tt1.Size = New System.Drawing.Size(76, 13)
        Me.tt1.TabIndex = 49
        Me.tt1.Text = "......................."
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(596, 149)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 13)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "total  :"
        '
        'tt2
        '
        Me.tt2.AutoSize = True
        Me.tt2.Location = New System.Drawing.Point(638, 209)
        Me.tt2.Name = "tt2"
        Me.tt2.Size = New System.Drawing.Size(76, 13)
        Me.tt2.TabIndex = 51
        Me.tt2.Text = "......................."
        '
        'tt3
        '
        Me.tt3.AutoSize = True
        Me.tt3.Location = New System.Drawing.Point(638, 261)
        Me.tt3.Name = "tt3"
        Me.tt3.Size = New System.Drawing.Size(76, 13)
        Me.tt3.TabIndex = 52
        Me.tt3.Text = "......................."
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.tt3)
        Me.Controls.Add(Me.tt2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.tt1)
        Me.Controls.Add(Me.tb)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.lbl_jmh3)
        Me.Controls.Add(Me.lbl_jmh2)
        Me.Controls.Add(Me.lbl_jmh1)
        Me.Controls.Add(Me.lbl_harga3)
        Me.Controls.Add(Me.lbl_harga2)
        Me.Controls.Add(Me.lbl_harga1)
        Me.Controls.Add(Me.lbl_pem3)
        Me.Controls.Add(Me.lbl_pem1)
        Me.Controls.Add(Me.lbl_pem2)
        Me.Controls.Add(Me.lbl_nama)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lbl_nama As Label
    Friend WithEvents lbl_pem2 As Label
    Friend WithEvents lbl_pem1 As Label
    Friend WithEvents lbl_pem3 As Label
    Friend WithEvents lbl_harga1 As Label
    Friend WithEvents lbl_harga2 As Label
    Friend WithEvents lbl_harga3 As Label
    Friend WithEvents lbl_jmh1 As Label
    Friend WithEvents lbl_jmh2 As Label
    Friend WithEvents lbl_jmh3 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents tb As Label
    Friend WithEvents tt1 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents tt2 As Label
    Friend WithEvents tt3 As Label
End Class
