﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txt_nama = New System.Windows.Forms.TextBox()
        Me.txt_pem3 = New System.Windows.Forms.TextBox()
        Me.txt_pem2 = New System.Windows.Forms.TextBox()
        Me.txt_pem1 = New System.Windows.Forms.TextBox()
        Me.jmh2 = New System.Windows.Forms.TextBox()
        Me.jmh3 = New System.Windows.Forms.TextBox()
        Me.jmh1 = New System.Windows.Forms.TextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Lavender
        Me.Label1.Location = New System.Drawing.Point(178, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "TOKO GORENGAN ABC"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(92, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nama"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 202)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Pembelian 1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(43, 255)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Pembelian 2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(43, 306)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Pembelian 3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(372, 137)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(342, 168)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Jumlah"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(372, 168)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 13)
        Me.Label8.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Location = New System.Drawing.Point(192, 346)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 28)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Check"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txt_nama
        '
        Me.txt_nama.Location = New System.Drawing.Point(133, 130)
        Me.txt_nama.Name = "txt_nama"
        Me.txt_nama.Size = New System.Drawing.Size(186, 20)
        Me.txt_nama.TabIndex = 9
        '
        'txt_pem3
        '
        Me.txt_pem3.Location = New System.Drawing.Point(133, 303)
        Me.txt_pem3.Name = "txt_pem3"
        Me.txt_pem3.Size = New System.Drawing.Size(124, 20)
        Me.txt_pem3.TabIndex = 10
        '
        'txt_pem2
        '
        Me.txt_pem2.Location = New System.Drawing.Point(133, 252)
        Me.txt_pem2.Name = "txt_pem2"
        Me.txt_pem2.Size = New System.Drawing.Size(124, 20)
        Me.txt_pem2.TabIndex = 11
        '
        'txt_pem1
        '
        Me.txt_pem1.Location = New System.Drawing.Point(133, 199)
        Me.txt_pem1.Name = "txt_pem1"
        Me.txt_pem1.Size = New System.Drawing.Size(124, 20)
        Me.txt_pem1.TabIndex = 12
        '
        'jmh2
        '
        Me.jmh2.Location = New System.Drawing.Point(326, 252)
        Me.jmh2.Name = "jmh2"
        Me.jmh2.Size = New System.Drawing.Size(79, 20)
        Me.jmh2.TabIndex = 13
        '
        'jmh3
        '
        Me.jmh3.Location = New System.Drawing.Point(326, 303)
        Me.jmh3.Name = "jmh3"
        Me.jmh3.Size = New System.Drawing.Size(79, 20)
        Me.jmh3.TabIndex = 14
        '
        'jmh1
        '
        Me.jmh1.Location = New System.Drawing.Point(326, 199)
        Me.jmh1.Name = "jmh1"
        Me.jmh1.Size = New System.Drawing.Size(79, 20)
        Me.jmh1.TabIndex = 15
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(28, 27)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(418, 367)
        Me.ListView1.TabIndex = 17
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"Daftar Menu:", "", "- Risol Mayo          3000                        - Bakwan                4500", "", "- Kroket                  2000                        - Pisang Goreng    5500", "", "- Gehu                    2500                        - Piscok                  3" &
                "500", "", "- Bolen                    5000                        - Mendoan            6000"})
        Me.ListBox1.Location = New System.Drawing.Point(465, 43)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(316, 160)
        Me.ListBox1.TabIndex = 18
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(793, 485)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.jmh1)
        Me.Controls.Add(Me.jmh3)
        Me.Controls.Add(Me.jmh2)
        Me.Controls.Add(Me.txt_pem1)
        Me.Controls.Add(Me.txt_pem2)
        Me.Controls.Add(Me.txt_pem3)
        Me.Controls.Add(Me.txt_nama)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txt_nama As TextBox
    Friend WithEvents txt_pem3 As TextBox
    Friend WithEvents txt_pem2 As TextBox
    Friend WithEvents txt_pem1 As TextBox
    Friend WithEvents jmh2 As TextBox
    Friend WithEvents jmh3 As TextBox
    Friend WithEvents jmh1 As TextBox
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ListBox1 As ListBox
End Class
