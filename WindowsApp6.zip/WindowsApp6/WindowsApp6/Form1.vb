﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim nama As String
        Dim pem1 As String
        Dim pem2 As String
        Dim pem3 As String
        Dim jumlah1 As Integer
        Dim jumlah2 As Integer
        Dim jumlah3 As Integer
        Dim harga1 As Integer
        Dim harga2 As Integer
        Dim harga3 As Integer
        Dim total1 As Integer
        Dim total2 As Integer
        Dim total3 As Integer
        Dim total As Integer

        nama = txt_nama.Text
        Form2.lbl_nama.Text = nama

        '------------------PEMBELIAN1------------------------------------------------------------------------'
        pem1 = txt_pem1.Text
        Form2.lbl_pem1.Text = pem1
        If pem1 = "risol mayo" Then
            harga1 = 3000
        ElseIf pem1 = "kroket" Then
            harga1 = 2000
        ElseIf pem1 = "gehu" Then
            harga1 = 2500
        ElseIf pem1 = "bakwan" Then
            harga1 = 4500
        ElseIf pem1 = "pisang goreng" Then
            harga1 = 5500
        ElseIf pem1 = "piscok" Then
            harga1 = 3500
        ElseIf pem1 = "bolen" Then
            harga1 = 5000
        ElseIf pem1 = "mendoan" Then
            harga1 = 6000
        Else
            harga1 = 0
        End If

        jumlah1 = jmh1.Text
        Form2.lbl_jmh1.Text = jumlah1

        Form2.lbl_harga1.Text = harga1

        total1 = jumlah1 * harga1
        Form2.tt1.Text = total1

        '-------------------PEMBELIAN2---------------------------------------------------------------------------'
        pem2 = txt_pem2.Text
        Form2.lbl_pem2.Text = pem2
        If pem2 = "risol mayo" Then
            harga2 = 3000
        ElseIf pem2 = "kroket" Then
            harga2 = 2000
        ElseIf pem2 = "gehu" Then
            harga2 = 2500
        ElseIf pem2 = "bakwan" Then
            harga2 = 4500
        ElseIf pem2 = "pisang goreng" Then
            harga2 = 5500
        ElseIf pem2 = "piscok" Then
            harga2 = 3500
        ElseIf pem2 = "bolen" Then
            harga2 = 5000
        ElseIf pem2 = "mendoan" Then
            harga1 = 6000
        Else
            harga2 = 0
        End If

        jumlah2 = jmh2.Text
        Form2.lbl_jmh2.Text = jumlah2

        Form2.lbl_harga2.Text = harga2

        total2 = jumlah2 * harga2
        Form2.tt2.Text = total2

        '------------------PEMBELIAN 3------------------------------------------------------------------------'
        pem3 = txt_pem3.Text
        Form2.lbl_pem3.Text = pem3
        If pem3 = "risol mayo" Then
            harga3 = 3000
        ElseIf pem3 = "kroket" Then
            harga3 = 2000
        ElseIf pem3 = "gehu" Then
            harga3 = 2500
        ElseIf pem3 = "bakwan" Then
            harga3 = 4500
        ElseIf pem3 = "pisang goreng" Then
            harga3 = 5500
        ElseIf pem3 = "piscok" Then
            harga3 = 3500
        ElseIf pem3 = "bolen" Then
            harga3 = 5000
        ElseIf pem3 = "mendoan" Then
            harga1 = 6000
        Else
            harga3 = 0
        End If

        jumlah3 = jmh3.Text
        Form2.lbl_jmh3.Text = jumlah3

        Form2.lbl_harga3.Text = harga3

        total3 = jumlah3 * harga3
        Form2.tt3.Text = total3


        total = total1 + total2 + total3
        Form2.tb.Text = total

        Form2.Show()


    End Sub


End Class
