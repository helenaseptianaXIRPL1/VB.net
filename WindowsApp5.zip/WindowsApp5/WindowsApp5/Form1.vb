﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim tugas As Double
        Dim quiz As Double
        Dim uts As Double
        Dim uas As Double
        Dim hasil As Double

        tugas = txt_tgs.Text
        tugas = tugas * 0.2
        quiz = txt_qz.Text
        quiz = quiz * 0.15
        uts = txt_uts.Text
        uts = uts * 0.3
        uas = txt_uas.Text
        uas = uas * 0.35

        hasil = tugas + quiz + uts + uas
        Me.txt_hasil.Text = hasil



    End Sub
End Class
