﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim tugas As Double
        Dim quiz As Double
        Dim uts As Double
        Dim uas As Double
        Dim hasil As Double
        Dim bonus As Integer

        tugas = txt_tgs.Text
        tugas = tugas * 0.2
        quiz = txt_qz.Text
        quiz = quiz * 0.15
        uts = txt_uts.Text
        uts = uts * 0.3
        uas = txt_uas.Text

        If uas > 80 Then
            bonus = 6

        ElseIf 80 > uas > 70 Then

            bonus = 4

        ElseIf 70 > uas > 66 Then
            bonus = 2

        Else
            bonus = 0
        End If

        uas = uas * 0.35

        hasil = tugas + quiz + uts + uas + bonus
        Me.txt_hasil.Text = hasil


    End Sub
End Class