﻿Public Class Form4
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBoxJabatan.SelectedItem IsNot Nothing Then
            Dim nama As String
            Dim jabatan As String = ComboBoxJabatan.SelectedItem.ToString()
            Dim jamKerja As Double
            Dim lembur As Double
            Dim tdkhadir As Integer

            Dim gajiPokok As Double
            Dim uangLembur As Double
            Dim uangMakan As Double
            Dim Potongan As Double
            Dim Total As Double
            Dim bonus As Double = 0

            Select Case jabatan
                Case "Manajer"
                    bonus += 6500000
                Case "Wakil Manajer"
                    bonus += 4500000
                Case "Kepala sub bagian"
                    bonus += 3000000
                Case "HRD"
                    bonus += 2000000
            End Select

            nama = txt_nm.Text
            jamKerja = txt_jamkerja.Text
            lembur = txt_lembur.Text
            tdkhadir = txt_tdkhadir.Text

            gajiPokok = jamKerja * 15000
            Me.txt_gajipokok.Text = gajiPokok

            uangLembur = lembur * 10000
            Me.txt_uanglembur.Text = uangLembur

            uangMakan = jamKerja * 10000
            Me.txt_uangmkn.Text = uangMakan

            Potongan = tdkhadir - 100000
            Me.txt_potong.Text = Potongan

            Total = gajiPokok + uangLembur + uangMakan + Potongan + bonus
            Me.txt_total.Text = Total

        Else
            MessageBox.Show("pilih jabatan telebih dahulu.")
        End If
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBoxJabatan.Items.Add("Manajer")
        ComboBoxJabatan.Items.Add("Wakil Manajer")
        ComboBoxJabatan.Items.Add("Kepala Sub Bagian")
        ComboBoxJabatan.Items.Add("HRD")
    End Sub
End Class