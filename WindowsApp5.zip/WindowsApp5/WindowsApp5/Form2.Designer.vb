﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_gajipokok = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txt_tdkhadir = New System.Windows.Forms.TextBox()
        Me.txt_lembur = New System.Windows.Forms.TextBox()
        Me.txt_jamkerja = New System.Windows.Forms.TextBox()
        Me.txt_nm = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_uanglembur = New System.Windows.Forms.TextBox()
        Me.txt_uangmkn = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_potong = New System.Windows.Forms.TextBox()
        Me.txt_total = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txt_gajipokok
        '
        Me.txt_gajipokok.Location = New System.Drawing.Point(238, 292)
        Me.txt_gajipokok.Name = "txt_gajipokok"
        Me.txt_gajipokok.Size = New System.Drawing.Size(100, 20)
        Me.txt_gajipokok.TabIndex = 25
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(159, 295)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Gaji Pokok"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(362, 249)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Hitung"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt_tdkhadir
        '
        Me.txt_tdkhadir.Location = New System.Drawing.Point(403, 206)
        Me.txt_tdkhadir.Name = "txt_tdkhadir"
        Me.txt_tdkhadir.Size = New System.Drawing.Size(100, 20)
        Me.txt_tdkhadir.TabIndex = 22
        '
        'txt_lembur
        '
        Me.txt_lembur.Location = New System.Drawing.Point(403, 166)
        Me.txt_lembur.Name = "txt_lembur"
        Me.txt_lembur.Size = New System.Drawing.Size(100, 20)
        Me.txt_lembur.TabIndex = 21
        '
        'txt_jamkerja
        '
        Me.txt_jamkerja.Location = New System.Drawing.Point(403, 124)
        Me.txt_jamkerja.Name = "txt_jamkerja"
        Me.txt_jamkerja.Size = New System.Drawing.Size(100, 20)
        Me.txt_jamkerja.TabIndex = 20
        '
        'txt_nm
        '
        Me.txt_nm.Location = New System.Drawing.Point(403, 87)
        Me.txt_nm.Name = "txt_nm"
        Me.txt_nm.Size = New System.Drawing.Size(100, 20)
        Me.txt_nm.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(298, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = " Jumlah tidak hadir"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(303, 166)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Jumlah lembur "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(303, 87)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Nama"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(303, 124)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Jumlah jam kerja"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(325, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Gaji Karyawan PT. ABC Abadi "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(159, 335)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Uang Lembur"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(434, 292)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 13)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Uang Makan"
        '
        'txt_uanglembur
        '
        Me.txt_uanglembur.Location = New System.Drawing.Point(238, 335)
        Me.txt_uanglembur.Name = "txt_uanglembur"
        Me.txt_uanglembur.Size = New System.Drawing.Size(100, 20)
        Me.txt_uanglembur.TabIndex = 28
        '
        'txt_uangmkn
        '
        Me.txt_uangmkn.Location = New System.Drawing.Point(519, 292)
        Me.txt_uangmkn.Name = "txt_uangmkn"
        Me.txt_uangmkn.Size = New System.Drawing.Size(100, 20)
        Me.txt_uangmkn.TabIndex = 29
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(434, 335)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Potongan"
        '
        'txt_potong
        '
        Me.txt_potong.Location = New System.Drawing.Point(519, 332)
        Me.txt_potong.Name = "txt_potong"
        Me.txt_potong.Size = New System.Drawing.Size(100, 20)
        Me.txt_potong.TabIndex = 32
        '
        'txt_total
        '
        Me.txt_total.Location = New System.Drawing.Point(403, 391)
        Me.txt_total.Name = "txt_total"
        Me.txt_total.Size = New System.Drawing.Size(100, 20)
        Me.txt_total.TabIndex = 33
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(325, 394)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 13)
        Me.Label10.TabIndex = 34
        Me.Label10.Text = "Total Gaji"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txt_total)
        Me.Controls.Add(Me.txt_potong)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txt_uangmkn)
        Me.Controls.Add(Me.txt_uanglembur)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt_gajipokok)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txt_tdkhadir)
        Me.Controls.Add(Me.txt_lembur)
        Me.Controls.Add(Me.txt_jamkerja)
        Me.Controls.Add(Me.txt_nm)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_gajipokok As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txt_tdkhadir As TextBox
    Friend WithEvents txt_lembur As TextBox
    Friend WithEvents txt_jamkerja As TextBox
    Friend WithEvents txt_nm As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_uanglembur As TextBox
    Friend WithEvents txt_uangmkn As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_potong As TextBox
    Friend WithEvents txt_total As TextBox
    Friend WithEvents Label10 As Label
End Class
