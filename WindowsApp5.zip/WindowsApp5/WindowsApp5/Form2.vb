﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim nama As String
        Dim jamKerja As Double
        Dim lembur As Double
        Dim tdkhadir As Integer

        Dim gajiPokok As Double
        Dim uangLembur As Double
        Dim uangMakan As Double
        Dim Potongan As Double
        Dim Total As Double

        nama = txt_nm.Text
        jamKerja = txt_jamkerja.Text
        lembur = txt_lembur.Text
        tdkhadir = txt_tdkhadir.Text

        gajiPokok = jamKerja * 15000
        Me.txt_gajipokok.Text = gajiPokok

        uangLembur = lembur * 10000
        Me.txt_uanglembur.Text = uangLembur

        uangMakan = jamKerja * 10000
        Me.txt_uangmkn.Text = uangMakan

        Potongan = tdkhadir - 100000
        Me.txt_potong.Text = Potongan

        Total = gajiPokok + uangLembur + uangMakan + Potongan
        Me.txt_total.Text = Total

    End Sub
End Class