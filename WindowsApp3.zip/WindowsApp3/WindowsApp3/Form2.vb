﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim P As Integer
        Dim L As Integer
        Dim luas As Integer

        P = txt_p.Text
        L = txt_l.Text

        luas = P * L

        Me.txt_hasil.Text = luas

    End Sub

    Private Sub txt_l_TextChanged(sender As Object, e As EventArgs) Handles txt_l.TextChanged

    End Sub

    Private Sub txt_p_TextChanged(sender As Object, e As EventArgs) Handles txt_p.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub txt_hasil_TextChanged(sender As Object, e As EventArgs) Handles txt_hasil.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class