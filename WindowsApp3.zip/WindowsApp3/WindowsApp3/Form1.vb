﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim sisi As Integer
        Dim luas As Integer

        sisi = txt_sisi.Text
        luas = sisi * sisi

        Me.txt_hasil.Text = luas

    End Sub
End Class
