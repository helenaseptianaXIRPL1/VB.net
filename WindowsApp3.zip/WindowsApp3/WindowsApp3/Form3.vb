﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim r As Integer
        Dim luas As Integer

        r = txt_r.Text


        luas = 3.14 * r * r


        Me.txt_hasil.Text = luas
    End Sub
End Class