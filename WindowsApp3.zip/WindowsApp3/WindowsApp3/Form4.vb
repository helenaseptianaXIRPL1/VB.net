﻿Public Class Form4
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim A As Integer
        Dim T As Integer
        Dim luas As Integer

        A = txt_a.Text
        T = txt_tinggi.Text

        luas = 0.5 * A * T

        Me.txt_hasil.Text = luas


    End Sub
End Class