﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim a%
        Dim b%
        Dim c%
        Dim d%
        Dim hasil As Integer

        a = txt_a.Text
        b = txt_b.Text
        c = txt_c.Text
        d = txt_d.Text



        hasil = (a + b) - (c * d)

        Me.txt_hasil.Text = hasil


    End Sub
End Class
