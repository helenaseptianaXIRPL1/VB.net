﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim p%
        Dim l%
        Dim t%
        Dim hasil As Integer

        p = txt_p.Text
        l = txt_l.Text
        t = txt_t.Text




        hasil = 2 * (p * l) + 2 * (p * l) + 2 * (t * l)

        Me.txt_hasil.Text = hasil

    End Sub
End Class