﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim alas As Integer
        Dim tinggi As Integer
        Dim luas As Integer

        alas = txt_alas.Text
        tinggi = txt_tinggi.Text
        luas = 0.5 * alas * tinggi

        Me.txt_hasil.Text = luas
    End Sub
End Class
