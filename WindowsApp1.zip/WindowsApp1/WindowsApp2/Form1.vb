﻿Public Class Form1


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim panjang As Integer
        Dim lebar As Integer
        Dim luas As Integer

        panjang = txt_panjang.Text
        lebar = txt_lebar.Text
        luas = panjang * lebar

        Me.txt_hasil.Text = luas



    End Sub
End Class