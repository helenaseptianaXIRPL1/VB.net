﻿Public Class Form2
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub txt_hasil_TextChanged(sender As Object, e As EventArgs) Handles txt_hasil.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim panjang As Integer
        Dim lebar As Integer
        Dim hasil As Integer

        panjang = txt_panjang.Text
        lebar = txt_lebar.Text
        hasil = panjang * lebar

        Me.txt_hasil.Text = hasil
    End Sub

    Private Sub txt_sisi_TextChanged(sender As Object, e As EventArgs) Handles txt_panjang.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class