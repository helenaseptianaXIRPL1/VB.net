﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim panjang As Integer
        Dim lebar As Integer
        Dim hasil As Integer

        panjang = txt_panjang.Text
        hasil = panjang * lebar

        Me.txt_hasil.Text = hasil




    End Sub
End Class
